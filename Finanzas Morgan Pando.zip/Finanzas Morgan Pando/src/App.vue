<template>
    <v-app>
        <v-main>
            <v-container>
                <router-view />
            </v-container>
        </v-main>
    </v-app>
</template>

<script>
export default {
    name: 'App',

    data: () => ({
        //
    }),
};
</script>

<style>
#app {
    color: #001866;
    background: rgb(0, 212, 255);
    background: linear-gradient(90deg, rgba(0, 212, 255, 1) 0%, rgba(72, 112, 245, 1) 23%, rgba(0, 24, 102, 1) 100%);
}

span {
    color: #4870f5;
    font-weight: bolder;
}
</style>
