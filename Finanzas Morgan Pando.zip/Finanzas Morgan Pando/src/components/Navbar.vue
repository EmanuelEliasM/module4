<template>
    <v-card class="mx-auto overflow-hidden">
        <v-navigation-drawer dark color="#121212" app v-model="drawer" permanent>
            <v-list nav dense>
                <v-list-item>
                    <v-layout column align-start> <h3>App Financiera UPC</h3></v-layout>
                </v-list-item>

                <template>
                    <div class="item-menu">
                        <span>{{ user.email }}</span>
                    </div>
                </template>
                <v-list-item-group active-class="primary--text text--accent-4" class="mt-5">
                    <v-list-item to="./">
                        <v-list-item-title>Inicio</v-list-item-title>
                        <v-list-item-icon> </v-list-item-icon>
                    </v-list-item>
                    <v-list-item to="./metodo-aleman">
                        <v-list-item-title>Método Alemán</v-list-item-title>
                        <v-list-item-icon> </v-list-item-icon>
                    </v-list-item>
                    <v-list-item to="./van-tir">
                        <v-list-item-title>VAN y TIR</v-list-item-title>
                        <v-list-item-icon> </v-list-item-icon>
                    </v-list-item>
                    <v-list-item @click.prevent="logout" class="logout">
                        <v-list-item-title>Cerrar Sesión</v-list-item-title>
                        <v-list-item-icon> </v-list-item-icon>
                    </v-list-item>
                </v-list-item-group>
            </v-list>
        </v-navigation-drawer>
    </v-card>
</template>

<script>
import '../firebase/init';
import firebase from 'firebase/compat/app';
export default {
    name: 'Navbar',
    data: () => ({
        drawer: false,
        group: null,
        user: null,
        menu: 'Diswallet',
    }),
    methods: {
        logout() {
            firebase
                .auth()
                .signOut()
                .then(() => {
                    this.$router.push({ name: 'Login' });
                });
        },
    },
    created() {
        firebase.auth().onAuthStateChanged(user => {
            if (user) {
                this.user = user;
            } else {
                this.user = null;
            }
        });
    },
};
</script>

<style scoped>
a {
    text-decoration: none;
}

.item-menu {
    padding: 4%;
}
.logout {
    background-color: rgb(94, 13, 13);
}
</style>
