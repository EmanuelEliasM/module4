import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/database';

const firebaseConfig = {
    apiKey: 'AIzaSyAQ74zhfj-QwwogEyYRyXQffobL6pJuZKU',
    authDomain: 'tf-finanzas-cbc63.firebaseapp.com',
    projectId: 'tf-finanzas-cbc63',
    storageBucket: 'tf-finanzas-cbc63.appspot.com',
    messagingSenderId: '551887271823',
    appId: '1:551887271823:web:dcc069e9d7b79ed63b3dfa',
};

const firebaseApp = firebase.initializeApp(firebaseConfig);

export default firebaseApp.database();
