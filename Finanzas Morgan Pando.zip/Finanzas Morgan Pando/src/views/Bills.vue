<template>
    <div>
        <Navbar></Navbar>
        <h1 class="text-center" style="color: white">Calcular amortización con el Método Alemán</h1>
        <v-card class="bills-card" elevation="12">
            <v-card-title>
                <!--DIALOG ADD BILLS-->
                <v-row>
                    <!--CUADRO DE DIALOGO NUEVA FACTURA-->
                    <v-dialog v-model="dialog" fullscreen hide-overlay max-width="100vh">
                        <template v-slot:activator="{ on, attrs }">
                            <v-btn color="primary" v-bind="attrs" v-on="on" class="mb-3">Nueva Operación </v-btn>
                        </template>
                        <v-spacer></v-spacer>

                        <v-card class="card-dialog" elevation="12">
                            <v-card-title class="justify-center">
                                <br /><br />
                                <br />
                                <span class="text-h3 formtitle">NUEVA OPERACIÓN</span>
                            </v-card-title>

                            <v-card-text>
                                <v-form class="mt-12" @submit.prevent="addBill">
                                    <v-container class="container-forms">
                                        <v-row>
                                            <v-col class="col-register" cols="12" sm="6">
                                                <v-subheader>Monto</v-subheader>
                                                <v-text-field
                                                    v-model="newBill.monto"
                                                    placeholder="0.00"
                                                    type="number"
                                                    outlined
                                                ></v-text-field>
                                            </v-col>
                                            <v-col class="col-register" cols="12" sm="6">
                                                <v-subheader>Tiempo (meses)</v-subheader>
                                                <v-text-field
                                                    v-model="newBill.tiempo"
                                                    placeholder="meses"
                                                    type="number"
                                                    outlined
                                                ></v-text-field>
                                            </v-col>
                                            <v-col class="col-register" cols="12" sm="6">
                                                <v-subheader>Interés mensual (%)</v-subheader>
                                                <v-text-field
                                                    v-model="newBill.interes"
                                                    placeholder="0.00%"
                                                    type="number"
                                                    outlined
                                                ></v-text-field>
                                                <p>MONEDA</p>
                                                <v-radio-group v-model="newBill.moneda" mandatory>
                                                    <v-radio label="SOLES" value="SOLES"></v-radio>
                                                    <v-radio label="DOLARES" value="DÓLARES"></v-radio>
                                                </v-radio-group>
                                            </v-col>
                                        </v-row>
                                        <div class="text-center mt-12">
                                            <v-btn color="primary" x-large type="submit">Registrar</v-btn>
                                            <br />
                                            <br />
                                            <v-btn large width="150px" @click="closeadd()"> Salir </v-btn>
                                        </div>
                                    </v-container>
                                </v-form>
                            </v-card-text>
                        </v-card>
                    </v-dialog>
                    <v-spacer></v-spacer>
                    <v-spacer></v-spacer>
                    <v-spacer></v-spacer>
                    <v-text-field
                        v-model="search"
                        append-icon="mdi-magnify"
                        label="Search"
                        solo
                        hide-details
                    ></v-text-field>

                    <!--CUADRO DE DIALOGO TABLA RESULTADOS -->
                    <v-dialog v-model="dialog2" fullscreen hide-overlay max-width="100vh">
                        <template v-slot:activator="{ on, attrs }">
                            <div color="primary" fab v-bind="attrs" v-on="on" disabled></div>
                        </template>

                        <v-card class="tcea-dialog" rounded="xl" elevation="12">
                            <v-card-title class="justify-center">
                                <span class="text-h3">RESULTADOS</span>
                            </v-card-title>
                            <v-card-text>
                                <v-data-table
                                    dense
                                    :headers="headersresults"
                                    :items="resultsitems"
                                    hide-default-footer
                                    items-per-page="50"
                                    item-key="fecha"
                                    class="elevation-1"
                                ></v-data-table>
                            </v-card-text>
                            <v-card-actions class="justify-center">
                                <v-btn large color="primary" width="150px" @click="closeresults()"> Salir </v-btn>
                            </v-card-actions>
                        </v-card>
                    </v-dialog>
                </v-row>
            </v-card-title>
            <v-divider light></v-divider>
            <v-data-table :headers="headers" :items="items" :search="search" hide-default-footer items-per-page="50">
                <template #item.resultados="{ item }">
                    <v-btn elevation="0" small @click.stop="getresults(item.id)"><span>Ver RESULTADOS</span></v-btn>
                </template>
            </v-data-table>
        </v-card>
    </div>
</template>

<script>
import firebase from 'firebase/compat/app';
import Navbar from '../components/Navbar.vue';
const dayjs = require('dayjs');
//import dayjs from 'dayjs' // ES 2015
dayjs().format();
let db = firebase.database();
let billsRef = db.ref('operation');
let resultsRef = db.ref('results');
let keysRef = db.ref('keysx');
export default {
    name: 'Bills',
    components: {
        Navbar,
    },

    firebase: {
        bills: billsRef,
        results: resultsRef,
        keysx: keysRef,
    },
    data() {
        return {
            totalfacturado: 'hola',
            search: '',
            headers: [
                { text: 'ID', value: 'id' },
                { text: 'Monto', value: 'monto' },
                { text: 'Tiempo (meses)', value: 'tiempo' },
                { text: 'Interés mensual', value: 'interes' },
                { text: 'MONEDA', value: 'moneda' },
                { text: 'Cronograma', value: 'resultados', sortable: false },
            ],
            headersresults: [
                { text: 'Fecha', value: 'fechax' },
                { text: 'Amortización', value: 'amortizacionx' },
                { text: 'Interés', value: 'interesx' },
                { text: 'Cuota', value: 'cuotax' },
                { text: 'Saldo', value: 'saldox' },
            ],

            butid: 0,
            items: [],
            resultsitems: [],
            id: 0,
            id2: 0,

            error: '',
            editedIndex: -1,
            dialog: false,
            dialog2: false,
            keys: {
                id: 0,
                key: '',
            },
            newresults: {
                fechax: '',
                amortizacionx: '',
                interesx: '',
                cuotax: '',
                saldox: '',
            },
            newtcea: {
                billid: '',
                tiempo: '',
                monto: '',
                interes: '',
                fecha: '',
                amortizacion: '',
                interes2: '',
                cuota: '',
                saldo: '',
                uid: 0,
            },
            newBill: {
                userid: 0,
                id: 0,
                tiempo: '',
                interes: '',
                monto: '',
                moneda: '',
                resultados: '',
            },
        };
    },
    created() {
        this.initialize();
    },

    methods: {
        xd() {
            this.dialog4 = true;
        },
        initialize: function () {
            billsRef.get().then(snapshot => {
                snapshot.forEach(doc => {
                    const bill = doc.val();
                    if (bill.userid == firebase.auth().currentUser.uid) {
                        this.items.push(bill);
                        this.tcea = bill.tcea;
                        this.id = bill.id;
                        console.log(this.tcea);
                        this.numitems = bill.id;
                    } else {
                        console.log('ID : ', bill.userid);
                        console.log('UID : ', firebase.auth().currentUser.uid);
                        console.log('next');
                    }
                });
            });
        },

        closebills() {
            this.dialog = false;
            this.$nextTick(() => {
                this.newBill = Object.assign({});
            });
        },

        closeresults() {
            this.dialog2 = false;
        },
        closeadd() {
            this.dialog = false;
        },
        addBill() {
            this.error = '';
            if (this.newBill.tiempo && this.newBill.interes && this.newBill.monto) {
                //ACTUALIZAR ID
                this.newBill.id = this.id + 1;
                this.id = this.id + 1;

                //ASIGNAR ID DE USUARIO
                this.newBill.userid = firebase.auth().currentUser.uid;
                console.log('USER ID : ', this.newBill.userid);

                //GUARDANDO KEY DE CADA ITEM
                this.keys.id = this.newBill.id;
                this.keys.key = billsRef.push(this.newBill).getKey();
                keysRef.push(this.keys);
                console.log(this.keys);
                this.items.push(this.newBill);
                //MANDAR EMISION, FECHA DE PAGO Y MONTO A DATABASE TCEA
                this.newBill.tceaID = this.newBill.id;

                this.closebills();
            } else {
                this.error = 'Todos los campos son requeridos.';
            }
        },

        getresults: function (btnid) {
            this.newtcea.billid = this.items[btnid - 1].id;
            this.newtcea.tiempo = this.items[btnid - 1].tiempo;
            this.newtcea.interes = this.items[btnid - 1].interes;
            this.newtcea.monto = this.items[btnid - 1].monto;
            console.log('tiempo: ', this.items[btnid - 1].tiempo);
            console.log('interes: ', this.items[btnid - 1].interes);
            console.log('monto: ', this.items[btnid - 1].monto);
            resultsRef.push(this.newtcea);
            this.butid = btnid;

            /*CÁLCULOS*/
            this.resultsitems = [];
            let mesActual = dayjs().add(1, 'month');
            let amortizacionConstante, pagoInteres, cuota;
            amortizacionConstante = this.newtcea.monto / this.newtcea.tiempo;
            for (let i = 1; i <= this.newtcea.tiempo; i++) {
                this.newresults = {};
                pagoInteres = this.newtcea.monto * (this.newtcea.interes / 100);
                cuota = amortizacionConstante + pagoInteres;
                this.newtcea.monto = this.newtcea.monto - amortizacionConstante;
                console.log('amoort: ', amortizacionConstante);
                console.log('pagoint: ', pagoInteres);
                let fecha = mesActual.format('DD-MM-YYYY');
                mesActual = mesActual.add(1, 'month');
                console.log('_____________');
                console.log('cuota: ', cuota);
                console.log('monto: ', this.newtcea.monto);
                console.log('fecha: ', fecha);
                this.newresults.fechax = fecha;
                this.newresults.amortizacionx = amortizacionConstante.toFixed(2);
                this.newresults.interesx = pagoInteres.toFixed(2);
                this.newresults.cuotax = cuota.toFixed(2);
                this.newresults.saldox = this.newtcea.monto.toFixed(2);
                console.log('newresults: ', this.newresults);
                this.resultsitems.push(this.newresults);
            }
            this.dialog2 = true;
        },
    },
};
</script>

<style scoped>
.bills-card {
    padding: 20px;
    margin: 50px;
}

.wallet-card {
    padding: 20px;
    margin: auto;
    width: 50%;
}

.col-register {
    padding-block: 0px;
}

.card-dialog {
    width: 100vh;
    padding: 5%;
}

.tcea-dialog {
    width: 100vh;
    padding: 3%;
}

.results-dialog {
    width: 100vh;
    padding: 5%;
    justify-content: center;
}

.formtasa {
    text-align: end;
    align-items: flex-end;
}

.switch-toggle {
    position: absolute;
    display: flex;
    left: 80%;
}

.resultado {
    padding: 10px;
    text-align: right;
}

.PEN {
    font-size: 15px;
}
</style>
