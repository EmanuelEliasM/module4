<template>
    <v-container>
        <Navbar></Navbar>
        <h1>Calcular VAN</h1>
        <br /><br /><br />
        <h1>Calcular TIR</h1>
    </v-container>
</template>

<script>
import Navbar from '../components/Navbar.vue';

export default {
    components: {
        Navbar,
    },
};
</script>

<style></style>
