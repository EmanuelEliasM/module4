<template class="containx">
    <v-container fluid fill-height>
        <v-row justify="center" align="center">
            <v-col cols="12" lg="6">
                <v-card class="pa-12 card-finance" elevation="20">
                    <v-card-title class="justify-center">
                        <v-alert v-if="error" color="red" type="error">
                            {{ error }}
                        </v-alert>
                        <h2 class="text-center">App Financiera UPC</h2>
                    </v-card-title>
                    <v-card-text>
                        <v-form class="mt-12" @submit.prevent="login">
                            <v-text-field
                                v-model="email"
                                outlined
                                autofocus
                                label="Email"
                                name="Email"
                                type="text"
                                color="primary accent-3"
                            />
                            <v-text-field
                                v-model="contraseña"
                                outlined
                                id="password"
                                label="Password"
                                name="password"
                                type="password"
                                color="primary accent-3"
                            />
                            <div class="text-center mt-2">
                                <v-btn large color="primary" type="submit">Iniciar Sesión</v-btn>
                                <p class="text-center mt-6">
                                    <router-link to="./register">Registrarme</router-link>
                                </p>
                            </div>
                        </v-form>
                    </v-card-text>
                </v-card>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
import '../firebase/init';
import firebase from 'firebase/compat/app';

export default {
    data() {
        return {
            email: '',
            contraseña: '',
            error: '',
        };
    },
    name: 'Login',
    methods: {
        login() {
            this.error = '';
            if (this.email && this.contraseña) {
                firebase
                    .auth()
                    .signInWithEmailAndPassword(this.email, this.contraseña)
                    .then(() => {
                        this.$router.push({ name: 'Home' });
                    })
                    .catch(err => {
                        this.error = err.message;
                    });
            } else {
                this.error = 'Todos los campos son requeridos.';
            }
        },
    },
};
</script>
}
<style scoped></style>
