<template>
    <div>
        <Navbar></Navbar>
        <v-parallax dark src="https://ithardware.pl/artykuly/hd/2452_1.jpg">
            <v-row align="center" justify="center">
                <v-col class="text-center" cols="12">
                    <h1 class="text-h2 mb-4">Bienvenido a tu App Financiera UPC</h1>
                    <h4 class="subheading font-weight-thin text-h4"><span>2022-1</span></h4>
                </v-col>
            </v-row>
        </v-parallax>
        <v-container>
            <v-card rounded="xl" elevation="12" class="mx-auto my-12" max-width="600px">
                <v-card-title class="justify-center text-center">
                    <h3>Calcular Amortización <br /><span>Método Alemán</span></h3>
                </v-card-title>
                <v-card-text><v-img class="fact" max-width="150" src="../assets/icon.png"></v-img></v-card-text>
                <v-card-actions class="justify-center c-text">
                    <router-link to="./metodo-aleman"><v-btn color="primary" rounded>Continuar</v-btn></router-link>
                </v-card-actions>
            </v-card>
        </v-container>
    </div>
</template>

<script>
import Navbar from '../components/Navbar.vue';

export default {
    name: 'Home',
    data() {
        return {};
    },
    components: {
        Navbar,
    },
};
</script>

<style scoped>
.fact {
    margin: auto;
}
.c-text {
    padding: 30px;
}
.text-parall {
    background-color: #121212;
    margin-left: auto;
}
</style>
