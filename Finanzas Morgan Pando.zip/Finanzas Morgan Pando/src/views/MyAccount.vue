<template>
  <div>
    <Navbar></Navbar>
    <h1>My Account</h1>
  </div>
</template>

<script>
import Navbar from "../components/Navbar.vue";

export default {
  components: {
    Navbar,
  },
};
</script>

<style scoped></style>
